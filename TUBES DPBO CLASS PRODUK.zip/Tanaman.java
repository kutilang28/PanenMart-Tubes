package Tubes.Dpbo;

public class Tanaman extends Produk {
    private String jenisTanaman;
    private String tingkatPerawatan;
    private String kebutuhanSinar;
    private int tinggi;
    private boolean potIncluded;
    
    public Tanaman(String idProduk, String nama, double harga, int stok, String deskripsi, String kategori,
                   String jenisTanaman, String tingkatPerawatan, String kebutuhanSinar, int tinggi, boolean potIncluded) {
        super(idProduk, nama, harga, stok, deskripsi, kategori);
        this.jenisTanaman = jenisTanaman;
        this.tingkatPerawatan = tingkatPerawatan;
        this.kebutuhanSinar = kebutuhanSinar;
        this.tinggi = tinggi;
        this.potIncluded = potIncluded;
    }

    public String getJenisTanaman() {
        return jenisTanaman;
    }

    public String rekomendasiPerawatan() {
        return "Perawatan: " + tingkatPerawatan;
    }
}