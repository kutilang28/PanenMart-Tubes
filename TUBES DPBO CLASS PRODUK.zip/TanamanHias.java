package Tubes.Dpbo;

public class TanamanHias extends Tanaman {
    private boolean bungaMekar;
    private String warnaBunga;

    public TanamanHias(String idProduk, String nama, double harga, int stok, String deskripsi, String kategori,
                       String jenisTanaman, String tingkatPerawatan, String kebutuhanSinar, int tinggi, boolean potIncluded,
                       boolean bungaMekar, String warnaBunga) {
        super(idProduk, nama, harga, stok, deskripsi, kategori, jenisTanaman, tingkatPerawatan, kebutuhanSinar, tinggi, potIncluded);
        this.bungaMekar = bungaMekar;
        this.warnaBunga = warnaBunga;
    }

    public String saranPenempatan() {
        return "Saran penempatan: " + (bungaMekar ? "Di tempat yang terang." : "Dapat diletakkan di dalam ruangan.");
    }
}