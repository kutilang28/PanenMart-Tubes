package Tubes.Dpbo;

public class Main {
    public static void main(String[] args) {
        BibitTanaman bibit = new BibitTanaman("B001", "Bibit Kenikir", 5000, 100,
                "Bibit sayuran sehat", "Bibit",
                "Sayuran", "Mudah", "Cukup Sinar", 30, true,
                30, "Semai.");

        TanamanHias tanamanHias = new TanamanHias("H001", "Sirih Gading", 75000, 50,
                "Tanaman hias yang indah", "Tanaman Hias",
                "Hiasan", "Mudah", "Cukup Sinar", 60, true,
                true, "Hijau");

        System.out.println(bibit.tampilkanInfo());
        System.out.println("Estimasi Panen: " + bibit.estimasiPanen() + " hari");

        System.out.println(tanamanHias.tampilkanInfo());
        System.out.println(tanamanHias.saranPenempatan());
    }
}