package Tubes.Dpbo;

public class Produk {
    private String idProduk;
    private String nama;
    private double harga;
    private int stok;
    private String deskripsi;
    private String kategori;

    public Produk(String idProduk, String nama, double harga, int stok, String deskripsi, String kategori) {
        this.idProduk = idProduk;
        this.nama = nama;
        this.harga = harga;
        this.stok = stok;
        this.deskripsi = deskripsi;
        this.kategori = kategori;
    }

    public String getIdProduk() {
        return idProduk;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public boolean cekStok() {
        return stok > 0;
    }

    public String tampilkanInfo() {
        return "ID: " + idProduk + ", Nama: " + nama + ", Harga: " + harga + ", Stok: " + stok + ", Deskripsi: " + deskripsi + ", Kategori: " + kategori;
    }
}