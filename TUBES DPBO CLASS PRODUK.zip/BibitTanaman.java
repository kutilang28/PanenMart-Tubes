package Tubes.Dpbo;

public class BibitTanaman extends Tanaman {
    private int masaPanen;
    private String metodeTanam;

    public BibitTanaman(String idProduk, String nama, double harga, int stok, String deskripsi, String kategori,
                        String jenisTanaman, String tingkatPerawatan, String kebutuhanSinar, int tinggi, boolean potIncluded,
                        int masaPanen, String metodeTanam) {
        super(idProduk, nama, harga, stok, deskripsi, kategori, jenisTanaman, tingkatPerawatan, kebutuhanSinar, tinggi, potIncluded);
        this.masaPanen = masaPanen;
        this.metodeTanam = metodeTanam;
    }

    public int estimasiPanen() {
        return masaPanen;
    }
}